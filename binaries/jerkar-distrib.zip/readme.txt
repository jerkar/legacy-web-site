org.jerkar.core.jar contains all the classes needed to run Jerkar (automation tool + build framework) and embedded libraries (Ivy and BouncyCastle).

org.jerkar.core-lean.jar contains only classes needed to run Jerkar (automation tool + build framework) but not embedded libraries (Ivy and BouncyCastle).

org.jerkar.core-all.jar contains org.jerkar.core.jar + the standard plugins (Jacoco and Sonar).