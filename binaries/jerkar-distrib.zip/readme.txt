org.jerkar.core.jar contains all the classes needed to run Jerkar (automation tool + build framework).

org.jerkar.core-fat.jar contains org.jerkar.core.jar + the standard plugins (Jacoco and Sonar).