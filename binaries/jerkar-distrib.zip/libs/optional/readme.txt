Libraries found here are not part of Jerkar classpath.

