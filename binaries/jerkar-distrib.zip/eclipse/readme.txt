Contains some libraries that are likely to be in Eclipse environment.
This directory is only intended for users who want Jerkar build extract build info from Eclipse metadata (.classpath file).

