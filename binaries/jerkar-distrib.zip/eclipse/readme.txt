Contains some library that is likely to be here in Eclipse environment.
This directory is only intended user who want Jerkar build extract build info 
from Eclipse metadata only (.classpath file).

